import java.util.LinkedList;

public class MaiorTen {
    public static void main(String[] args) {
        
        LinkedList<Integer> numero = new LinkedList<Integer>();
        numero.add(6);
        numero.add(12);
        numero.add(15);
        numero.add(20);
        numero.add(9);
        
        int contar = 0;
        for (int num : numero) {
            if (num > 10) {
                contar++;
            }
        }
        System.out.println("Lista de números: " + numero);
        System.out.println("Quantidade de números maiores que 10: " + contar + " números. ");
    }
}