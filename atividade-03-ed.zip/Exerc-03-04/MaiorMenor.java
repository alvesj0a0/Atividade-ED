import java.util.LinkedList;

public class MaiorMenor{
    public static void main(String[] args) {
        
        LinkedList<Integer> numero = new LinkedList<Integer>();
        numero.add(5);
        numero.add(12);
        numero.add(15);
        numero.add(20);
        numero.add(9);
        
        int somaMaior = 0;
        int somaMenor = 0;
        int pares = 0;
        
        for (int num : numero) {
            if (num > 10) {
                somaMaior += num;
                } else{
                    somaMenor += num;
                }
                if (num % 2 == 0) {
                    pares++;
                }
        }
        
        System.out.println("Lista de números: " + numero);
        System.out.println("Soma dos números maiores que 10: " + somaMaior);
        System.out.println("Soma dos números menores que 10: " + somaMenor);
        System.out.println("Quantidade de números pares: " + pares);
    }
}