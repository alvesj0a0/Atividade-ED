import java.util.LinkedList;

public class Lista {
    public static void main(String[] ags) {
        LinkedList<String> people = new LinkedList<String>();
        people.addLast("ana");
        people.addLast("maria");
        people.addLast("joão");
        people.addLast("Célia");
        people.addLast("Igor");
        
        System.out.println("LIsta inicial de clientes; " + people);
        
        String atendido= people.removeFirst();
        System.out.println("Cliente atendido: "+ atendido);
        System.out.println("Lista depois do atendimento: " + people);
    }
    
}